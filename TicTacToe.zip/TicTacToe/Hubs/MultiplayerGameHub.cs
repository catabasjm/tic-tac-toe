using Microsoft.AspNetCore.SignalR;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class MultiplayerGameHub : Hub
{
    private static Dictionary<string, string> players = new(); // Tracks player connections (ID -> X or O)
    private static char[] board = new char[9]; // Represents the Tic-Tac-Toe board
    private static char currentPlayer = 'X';   // Current player (X or O)
    private static bool gameActive = false;    // Game starts only when both players join
    private static Dictionary<string, int> scores = new(); // Tracks wins, losses, and draws for each player

    public async Task JoinGame(string selectedPlayer)
    {
        if (players.Count >= 2)
        {
            await Clients.Caller.SendAsync("GameFull", "Game is full. Please wait for the next round.");
            return;
        }

        // Assign the selected player their chosen symbol
        if (!players.ContainsValue(selectedPlayer))
        {
            players[Context.ConnectionId] = selectedPlayer;
        }
        else
        {
            // Assign the opposite symbol to the second player
            players[Context.ConnectionId] = selectedPlayer == "X" ? "O" : "X";
        }

        // Initialize scores for the new player
        scores[Context.ConnectionId] = 0;

        await Clients.Caller.SendAsync("AssignPlayer", players[Context.ConnectionId]);
        await Clients.All.SendAsync("UpdatePlayers", players.Values.ToList());

        if (players.Count == 2)
        {
            gameActive = true; // Start the game only when both players are connected
            await Clients.All.SendAsync("GameReady", "Game starts now! Player X goes first.");
            await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);
        }
        else
        {
            await Clients.Caller.SendAsync("WaitingForOpponent", "Waiting for another player to join...");
        }
    }

    public async Task SendMove(int cellIndex, string player)
    {
        if (!gameActive)
        {
            await Clients.Caller.SendAsync("InvalidMove", "Game has not started yet. Please wait for another player.");
            return;
        }

        if (players.Count < 2)
        {
            await Clients.Caller.SendAsync("InvalidMove", "Waiting for another player to join...");
            return;
        }

        if (player[0] != currentPlayer)
        {
            await Clients.Caller.SendAsync("InvalidMove", "It's not your turn!");
            return;
        }

        if (cellIndex < 0 || cellIndex >= 9 || board[cellIndex] != '\0')
        {
            await Clients.Caller.SendAsync("InvalidMove", "Invalid move. Please try again.");
            return;
        }

        board[cellIndex] = player[0];
        await Clients.All.SendAsync("ReceiveMove", cellIndex, player);

        if (CheckWin(player[0]))
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", $"Game Over! Player {player} wins!", player);

            // Update scores
            foreach (var connectionId in players.Keys)
            {
                if (players[connectionId] == player)
                {
                    scores[connectionId]++; // Increment wins for the winning player
                }
                else
                {
                    scores[connectionId]--; // Increment losses for the losing player
                }
            }

            await Clients.All.SendAsync("UpdateScores", scores);
            return;
        }

        if (CheckDraw())
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", "Game Over! It's a Draw!", "draw");

            // Update scores for a draw
            foreach (var connectionId in players.Keys)
            {
                scores[connectionId]++; // Increment draws for both players
            }

            await Clients.All.SendAsync("UpdateScores", scores);
            return;
        }

        // Switch turn
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);
    }

    public async Task ResetGame()
    {
        for (int i = 0; i < board.Length; i++)
            board[i] = '\0';

        gameActive = players.Count == 2; // Ensure game only starts if two players are present
        currentPlayer = 'X';

        await Clients.All.SendAsync("ResetGame");
        if (gameActive)
            await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);
        else
            await Clients.All.SendAsync("WaitingForOpponent", "Waiting for another player to join...");
    }

    private bool CheckWin(char player)
    {
        int[][] winningCombinations = new int[][]
        {
            new int[] { 0, 1, 2 }, new int[] { 3, 4, 5 }, new int[] { 6, 7, 8 },
            new int[] { 0, 3, 6 }, new int[] { 1, 4, 7 }, new int[] { 2, 5, 8 },
            new int[] { 0, 4, 8 }, new int[] { 2, 4, 6 }
        };

        return winningCombinations.Any(c => board[c[0]] == player && board[c[1]] == player && board[c[2]] == player);
    }

    private bool CheckDraw() => board.All(cell => cell != '\0') && !CheckWin('X') && !CheckWin('O');

    public override async Task OnDisconnectedAsync(System.Exception exception)
    {
        if (players.ContainsKey(Context.ConnectionId))
        {
            string player = players[Context.ConnectionId];
            players.Remove(Context.ConnectionId);
            scores.Remove(Context.ConnectionId); // Remove player's score
            gameActive = false; // Pause game when a player leaves
            await Clients.All.SendAsync("PlayerDisconnected", player);
            await Clients.All.SendAsync("WaitingForOpponent", "A player has left. Waiting for a new player...");
        }
        await base.OnDisconnectedAsync(exception);
    }
}