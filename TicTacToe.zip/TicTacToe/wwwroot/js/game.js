﻿const connection = new signalR.HubConnectionBuilder()
    .withUrl("/gameHub")
    .build();

let currentPlayer = 'X'; // Track the current player locally (optional, can be managed by server)
const cells = document.querySelectorAll('.cell');
const resetButton = document.getElementById('resetButton');
const gameStatus = document.getElementById('gameStatus');

// Handle receiving a move from the server
connection.on("ReceiveMove", (cellIndex, player) => {
    cells[cellIndex].textContent = player; // Update the cell with the player's mark
});

// Handle game over conditions
connection.on("GameOver", (message) => {
    gameStatus.textContent = message; // Display the game over message
    document.querySelector('.game-board').classList.add('game-over'); // Disable further moves
});

// Handle resetting the game
connection.on("ResetGame", () => {
    cells.forEach(cell => {
        cell.textContent = ''; // Clear the cell content
        cell.style.pointerEvents = 'auto'; // Re-enable clicks
    });
    gameStatus.textContent = "Player X's turn"; // Reset the game status
    document.querySelector('.game-board').classList.remove('game-over'); // Re-enable the board
});

// Handle updating the current player
connection.on("UpdateCurrentPlayer", (player) => {
    currentPlayer = player; // Update the current player
    gameStatus.textContent = `Player ${player}'s turn`; // Update the game status
});

// Handle invalid moves
connection.on("InvalidMove", (message) => {
    alert(message); // Show an alert for invalid moves
});

// Connect to the SignalR hub
connection.start().catch(err => console.error(err.toString()));

// Send a move to the server when a cell is clicked
cells.forEach(cell => {
    cell.addEventListener('click', () => {
        const cellIndex = cell.getAttribute('data-index'); // Get the cell index
        connection.invoke("SendMove", parseInt(cellIndex), currentPlayer).catch(err => console.error(err.toString())); // Send the move to the server
    });
});

// Reset the game when the reset button is clicked
resetButton.addEventListener('click', () => {
    connection.invoke("ResetGame").catch(err => console.error(err.toString())); // Send a reset request to the server
});