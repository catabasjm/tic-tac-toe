using Microsoft.AspNetCore.SignalR;
using System;
using System.Linq;
using System.Threading.Tasks;

public class BotGameHub : Hub
{
    private static char[] board = new char[9]; // Tic-Tac-Toe board
    private static char currentPlayer = 'X';   // Player's turn
    private static bool gameActive = true;     // Game status

    public async Task StartGame()
    {
        ResetBoard();
        gameActive = true;
        currentPlayer = 'X'; // Player always starts first

        await Clients.Caller.SendAsync("GameStarted", board);
        await Clients.Caller.SendAsync("UpdateCurrentPlayer", currentPlayer);
    }

    public async Task SendMove(int cellIndex)
    {
        if (!gameActive || cellIndex < 0 || cellIndex >= 9 || board[cellIndex] != '\0')
        {
            await Clients.Caller.SendAsync("InvalidMove", "Invalid move. Try again.");
            return;
        }

        // Player's move
        board[cellIndex] = 'X';
        await Clients.All.SendAsync("ReceiveMove", cellIndex, 'X');

        if (CheckWin('X'))
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", "Game Over! You win!");
            return;
        }

        if (CheckDraw())
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", "Game Over! It's a Draw!");
            return;
        }

        // Bot's turn
        currentPlayer = 'O';
        await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);

        await Task.Delay(500); // Simulate thinking delay
        int botMove = GetBotMove();
        if (botMove != -1)
        {
            board[botMove] = 'O';
            await Clients.All.SendAsync("ReceiveMove", botMove, 'O');
        }

        if (CheckWin('O'))
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", "Game Over! Bot wins!");
            return;
        }

        if (CheckDraw())
        {
            gameActive = false;
            await Clients.All.SendAsync("GameOver", "Game Over! It's a Draw!");
            return;
        }

        currentPlayer = 'X';
        await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);
    }

    public async Task ResetGame()
    {
        ResetBoard();
        gameActive = true;
        currentPlayer = 'X';

        await Clients.All.SendAsync("ResetGame");
        await Clients.All.SendAsync("UpdateCurrentPlayer", currentPlayer);
    }

    private void ResetBoard()
    {
        for (int i = 0; i < board.Length; i++)
            board[i] = '\0';
    }

    private bool CheckWin(char player)
    {
        int[][] winningCombinations = new int[][]
        {
            new int[] { 0, 1, 2 }, new int[] { 3, 4, 5 }, new int[] { 6, 7, 8 },
            new int[] { 0, 3, 6 }, new int[] { 1, 4, 7 }, new int[] { 2, 5, 8 },
            new int[] { 0, 4, 8 }, new int[] { 2, 4, 6 }
        };

        return winningCombinations.Any(c => board[c[0]] == player && board[c[1]] == player && board[c[2]] == player);
    }

    private bool CheckDraw() => board.All(cell => cell != '\0') && !CheckWin('X') && !CheckWin('O');

    private int GetBotMove()
    {
        Random rand = new();
        var availableMoves = board.Select((val, index) => (val, index))
                                  .Where(cell => cell.val == '\0')
                                  .Select(cell => cell.index)
                                  .ToList();

        return availableMoves.Count > 0 ? availableMoves[rand.Next(availableMoves.Count)] : -1;
    }
}
