using Microsoft.AspNetCore.Mvc;

namespace TicTacToe.Controllers
{
    public class GameController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Asynch()
        {
            return View();
        }
        public IActionResult Multiplayer()
        {
            return View();
        }
        public IActionResult Bot()
        {
            return View();
        }
    }
}
