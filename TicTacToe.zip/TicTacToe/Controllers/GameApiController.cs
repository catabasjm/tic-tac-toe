using Microsoft.AspNetCore.Mvc;
using System;

[ApiController]
[Route("api/game")]
public class GameApiController : ControllerBase 
{
    private static char[] board = new char[9]; // Represents the 3x3 grid
    private static char currentPlayer = 'X';   // Current player (X or O)
    private static bool gameActive = true;    // Whether the game is still active

    [HttpPost("move")]
    public IActionResult MakeMove([FromBody] MoveRequest request)
    {
        if (!gameActive || request.CellIndex < 0 || request.CellIndex >= 9 || board[request.CellIndex] != '\0')
        {
            return BadRequest("Invalid move. Please try again.");
        }

        board[request.CellIndex] = request.Player[0];

        if (CheckWin(request.Player[0]))
        {
            gameActive = false;
            return Ok(new { Message = $"Game Over! Player {request.Player} wins!", Board = board });
        }

        if (CheckDraw())
        {
            gameActive = false;
            return Ok(new { Message = "Game Over! It's a Draw!", Board = board });
        }

        currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
        return Ok(new { Message = $"Player {currentPlayer}'s turn", Board = board });
    }

    [HttpPost("reset")]
    public IActionResult ResetGame()
    {
        ResetBoard();
        gameActive = true;
        currentPlayer = 'X';
        return Ok(new { Message = "Game reset. Player X's turn.", Board = board });
    }

    private void ResetBoard()
    {
        for (int i = 0; i < board.Length; i++)
        {
            board[i] = '\0'; // Reset each cell to empty
        }
    }

    private bool CheckWin(char player)
    {
        int[][] winningCombinations = new int[][]
        {
            new int[] { 0, 1, 2 }, new int[] { 3, 4, 5 }, new int[] { 6, 7, 8 },
            new int[] { 0, 3, 6 }, new int[] { 1, 4, 7 }, new int[] { 2, 5, 8 },
            new int[] { 0, 4, 8 }, new int[] { 2, 4, 6 }
        };

        foreach (var combination in winningCombinations)
        {
            if (board[combination[0]] == player && board[combination[1]] == player && board[combination[2]] == player)
            {
                return true;
            }
        }
        return false;
    }

    private bool CheckDraw()
    {
        return Array.TrueForAll(board, cell => cell != '\0') && !CheckWin('X') && !CheckWin('O');
    }
}

public class MoveRequest
{
    public int CellIndex { get; set; }
    public string Player { get; set; }
}
